``jax.experimental.checkify`` module
====================================


.. automodule:: jax.experimental.checkify

API
---

.. autosummary::
   :toctree: _autosummary

   checkify
   check
   check_error
   Error
   JaxRuntimeError
   user_checks
   nan_checks
   index_checks
   div_checks
   float_checks
   automatic_checks
   all_checks
