Installing JAX
==============

JAX is available to install via the `Python Package Index`_.
For full installation instructions, please refer to the `Install Guide`_ in the project README.

.. _Python Package Index: https://pypi.org/project/jax/
.. _Install Guide: https://github.com/google/jax#installation
