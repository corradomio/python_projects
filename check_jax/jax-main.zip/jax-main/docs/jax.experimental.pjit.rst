``jax.experimental.pjit`` module
================================

.. automodule:: jax.experimental.pjit

API
---

.. autofunction:: pjit
