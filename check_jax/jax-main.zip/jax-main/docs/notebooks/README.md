For instructions on how to change and test notebooks, see 
[Update Documentation](https://jax.readthedocs.io/en/latest/developer.html#update-documentation). 
