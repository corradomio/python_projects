Configuration files for self-hosted Github Actions runners. We use self-hosted
Cloud TPU VM runners for TPU CI.

Googlers, see go/jax-self-hosted-runners for more information.
